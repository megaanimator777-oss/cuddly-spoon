@file:OptIn(ExperimentalMaterial3Api::class)

package com.dizz.player

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Dim = Color.White.copy(alpha = 0.55f)

/** Выбор визуализации прямо в плеере: встроенные стили, свои .viz и кнопка «+ .viz». */
@Composable
fun VizPicker() {
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) VizStore.importAsync(ctx, u)
    }
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        STYLES.forEachIndexed { i, s ->
            FilterChip(
                selected = Cfg.vizPack.isEmpty() && Cfg.style == i,
                onClick = { Cfg.style = i; VizStore.activate(ctx, "") },
                label = { Text(s) }
            )
        }
        VizStore.list.forEach { v ->
            FilterChip(
                selected = Cfg.vizPack == v.id,
                onClick = { VizStore.activate(ctx, v.id) },
                label = { Text(v.id, maxLines = 1) }
            )
        }
        FilterChip(selected = false, onClick = { pick.launch(arrayOf("*/*")) }, label = { Text("+ .viz") })
    }
    if (VizStore.loading) Text("Загружаю шаблон…", fontSize = 11.sp, color = Dim, modifier = Modifier.padding(top = 4.dp))
    else if (VizStore.message.startsWith("Не удалось")) Text(VizStore.message, fontSize = 11.sp, color = Color(0xFFFF8A80), modifier = Modifier.padding(top = 4.dp))
}

/** Раздел настроек: добавить, выбрать и удалить шаблоны .viz. */
@Composable
fun VizSection() {
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) VizStore.importAsync(ctx, u)
    }
    var del by remember { mutableStateOf<String?>(null) }

    Section("Шаблоны .viz") {
        Text(
            "Добавьте файл визуализации .viz (формат Avee Player). Можно выбрать файл кнопкой ниже или открыть .viz из файлового менеджера, мессенджера или браузера через «Открыть с помощью» → DizzPlayer.",
            fontSize = 12.sp, color = Dim
        )
        Button({ pick.launch(arrayOf("*/*")) }, Modifier.padding(top = 10.dp), shape = RoundedCornerShape(24.dp)) { Text("Добавить файл .viz") }
        if (VizStore.loading) {
            Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("Загружаю шаблон…", fontSize = 12.sp, color = Dim)
            }
        }
        if (VizStore.message.isNotEmpty()) {
            Text(
                VizStore.message, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
                color = if (VizStore.message.startsWith("Не удалось")) Color(0xFFFF8A80) else Dim
            )
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp).clickable { VizStore.activate(ctx, "") },
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(selected = Cfg.vizPack.isEmpty(), onClick = { VizStore.activate(ctx, "") })
            Text("Встроенные визуализации")
        }
        VizStore.list.forEach { v ->
            Row(
                Modifier.fillMaxWidth().clickable { VizStore.activate(ctx, v.id) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = Cfg.vizPack == v.id, onClick = { VizStore.activate(ctx, v.id) })
                Column(Modifier.weight(1f)) {
                    Text(v.id, maxLines = 1)
                    Text("${v.sizeKb} КБ", fontSize = 11.sp, color = Dim)
                }
                IconButton({ del = v.id }) { Icon(Icons.Default.Delete, null, tint = Dim) }
            }
        }
        if (VizStore.list.isEmpty()) Text("Шаблонов пока нет.", fontSize = 12.sp, color = Dim, modifier = Modifier.padding(top = 6.dp))
        Sl("Качество картинки", Cfg.vizQuality, 0.3f..1f, "${(Cfg.vizQuality * 100).toInt()}%") { Cfg.vizQuality = it }
        Text(
            "Шаблоны тяжёлые (размытие, частицы). Если картинка тормозит — уменьшите качество до 40–60%.",
            fontSize = 11.sp, color = Dim
        )
        Text(
            "Поддерживается: картинки и маски, спектр-бары, частицы, текст, размытие, зеркало, RGB-сдвиг, дрожание и пульс на бит. FOV, Liquify и Motion Blur показываются упрощённо. Обложка трека подставляется в шаблон автоматически.",
            fontSize = 11.sp, color = Dim, modifier = Modifier.padding(top = 6.dp)
        )
    }

    del?.let { id ->
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("Удалить «$id»?") },
            text = { Text("Файл шаблона будет удалён из приложения. Оригинал на телефоне не затрагивается.") },
            confirmButton = { TextButton({ VizStore.delete(ctx, id); del = null }) { Text("Удалить") } },
            dismissButton = { TextButton({ del = null }) { Text("Отмена") } }
        )
    }
}
