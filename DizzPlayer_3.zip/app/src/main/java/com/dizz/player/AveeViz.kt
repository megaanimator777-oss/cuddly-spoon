package com.dizz.player

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrixColorFilter
import android.graphics.LightingColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.util.LruCache
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import org.json.JSONObject
import java.io.File
import java.util.IdentityHashMap
import java.util.concurrent.Executors
import java.util.zip.ZipFile
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/*
 * Поддержка шаблонов визуализаций .viz (формат Avee Player): zip-архив со scene.json и ресурсами.
 * scene.json — граф «композиций». Композиция №0 — итоговая картинка; другие композиции используются
 * как текстуры, маски и цели эффектов. Реализован практичный поднабор: Image, Bars, Particles, Text,
 * Blur / MotionBlur / RgbSplit / Mirror (FOV и Liquify рисуются без искажения).
 */

// ---------- чтение JSON-свойств вида {"v": значение, "t": тип, ...} ----------

private fun JSONObject.pv(k: String): Any? {
    val o = optJSONObject(k) ?: return null
    return if (o.has("v") && !o.isNull("v")) o.get("v") else null
}

private fun JSONObject.nm(k: String, d: Float): Float {
    val v = pv(k) ?: return d
    return when (v) {
        is Number -> v.toFloat()
        is String -> v.trim().split(Regex("\\s+")).firstNotNullOfOrNull { it.toFloatOrNull() } ?: d
        else -> d
    }
}

private fun JSONObject.fl(k: String, d: Boolean): Boolean {
    val v = pv(k)
    return if (v is Number) v.toInt() != 0 else d
}

private fun JSONObject.st(k: String, d: String = ""): String = pv(k)?.toString() ?: d

private fun JSONObject.v2(k: String, dx: Float, dy: Float): FloatArray {
    val s = pv(k)?.toString() ?: return floatArrayOf(dx, dy)
    val p = s.trim().split(Regex("\\s+")).mapNotNull { it.toFloatOrNull() }
    return when {
        p.size >= 2 -> floatArrayOf(p[0], p[1])
        p.size == 1 -> floatArrayOf(p[0], p[0])
        else -> floatArrayOf(dx, dy)
    }
}

private fun hsl(h: Float, s: Float, l: Float, a: Float): Int {
    val hh = ((h % 1f) + 1f) % 1f
    val q = if (l < 0.5f) l * (1f + s) else l + s - l * s
    val p = 2f * l - q
    fun f(t0: Float): Float {
        var t = t0
        if (t < 0f) t += 1f
        if (t > 1f) t -= 1f
        return when {
            t < 1f / 6f -> p + (q - p) * 6f * t
            t < 0.5f -> q
            t < 2f / 3f -> p + (q - p) * (2f / 3f - t) * 6f
            else -> p
        }
    }
    val r = (f(hh + 1f / 3f) * 255f).roundToInt().coerceIn(0, 255)
    val g = (f(hh) * 255f).roundToInt().coerceIn(0, 255)
    val b = (f(hh - 1f / 3f) * 255f).roundToInt().coerceIn(0, 255)
    return Color.argb((a * 255f).roundToInt().coerceIn(0, 255), r, g, b)
}

private fun JSONObject.col(k: String, d: Int): Int {
    val v = pv(k) ?: return d
    return when (v) {
        is Number -> v.toInt()
        is String -> {
            val p = v.trim().split(Regex("\\s+")).mapNotNull { it.toFloatOrNull() }
            when {
                p.size >= 4 -> hsl(p[0], p[1], p[2], p[3])
                p.size == 3 -> hsl(p[0], p[1], p[2], 1f)
                else -> d
            }
        }
        else -> d
    }
}

private fun lerpC(a: Int, b: Int, f: Float): Int {
    val x = f.coerceIn(0f, 1f)
    fun m(sa: Int, sb: Int) = (sa + (sb - sa) * x).roundToInt().coerceIn(0, 255)
    return Color.argb(m(Color.alpha(a), Color.alpha(b)), m(Color.red(a), Color.red(b)), m(Color.green(a), Color.green(b)), m(Color.blue(a), Color.blue(b)))
}

private fun tint(c: Int): ColorFilter? {
    if (c == -1) return null
    val r = Color.red(c) / 255f; val g = Color.green(c) / 255f; val b = Color.blue(c) / 255f; val a = Color.alpha(c) / 255f
    return ColorMatrixColorFilter(floatArrayOf(r, 0f, 0f, 0f, 0f, 0f, g, 0f, 0f, 0f, 0f, 0f, b, 0f, 0f, 0f, 0f, 0f, a, 0f))
}

private val ADD = PorterDuffXfermode(PorterDuff.Mode.ADD)
private val SCREEN = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
private val DST_IN = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
private val DST_OUT = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)

private fun blendOf(e: JSONObject): PorterDuffXfermode? = when (e.st("blendMode", "Alpha")) {
    "Add", "AddAlpha" -> ADD
    "Screen" -> SCREEN
    else -> null
}

// ---------- сцена ----------

class AveeScene(val id: String, val file: File, val comps: List<List<JSONObject>>, val providers: List<JSONObject>) {
    val assetNames: List<String> by lazy {
        try { ZipFile(file).use { z -> z.entries().asSequence().map { it.name }.filter { it != "scene.json" && !it.endsWith(".json") }.toList() } }
        catch (e: Exception) { emptyList() }
    }
}

object Avee {
    fun parse(f: File, id: String): AveeScene {
        return ZipFile(f).use { z ->
            val e = z.getEntry("scene.json") ?: throw Exception("в архиве нет scene.json — это не шаблон визуализации")
            val txt = z.getInputStream(e).use { it.readBytes() }.toString(Charsets.UTF_8)
            val root = JSONObject(txt)
            val arr = root.optJSONArray("compositions") ?: throw Exception("в scene.json нет списка compositions")
            val comps = ArrayList<List<JSONObject>>()
            val provs = ArrayList<JSONObject>()
            for (i in 0 until arr.length()) {
                val els = arr.getJSONObject(i).optJSONArray("elements")
                val l = ArrayList<JSONObject>()
                if (els != null) for (j in 0 until els.length()) {
                    val el = els.optJSONObject(j) ?: continue
                    l.add(el)
                    if (el.optString("objType") == "AudioProvider") provs.add(el)
                }
                comps.add(l)
            }
            if (comps.isEmpty()) throw Exception("пустая сцена")
            AveeScene(id, f, comps, provs)
        }
    }

    /** Быстрая проверка без разбора всего JSON: это zip со scene.json? */
    fun looksValid(f: File): Boolean = try { ZipFile(f).use { it.getEntry("scene.json") != null } } catch (e: Exception) { false }
}

// ---------- ресурсы шаблона ----------

object AveeAssets {
    private val cache = object : LruCache<String, Bitmap>(72 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val busy = HashSet<String>()
    private val ex = Executors.newFixedThreadPool(2)

    private fun decode(bytes: ByteArray): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > 1280) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        o2.inPreferredConfig = Bitmap.Config.ARGB_8888
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }

    /** Возвращает картинку, если она уже загружена; иначе запускает фоновую загрузку и отдаёт null. */
    fun get(sc: AveeScene, name: String): Bitmap? {
        val key = sc.id + "|" + name
        synchronized(this) {
            val hit = cache.get(key)
            if (hit != null) return hit
            if (!busy.add(key)) return null
        }
        ex.execute {
            var ok = false
            try {
                ZipFile(sc.file).use { z ->
                    val e = z.getEntry(name)
                    if (e != null) {
                        val bmp = decode(z.getInputStream(e).use { it.readBytes() })
                        if (bmp != null) { synchronized(this) { cache.put(key, bmp) }; ok = true }
                    }
                }
            } catch (t: Throwable) { }
            // неудачные ключи остаются в busy — повторно не пробуем
            if (ok) synchronized(this) { busy.remove(key) }
        }
        return null
    }

    fun preload(sc: AveeScene) { for (n in sc.assetNames) get(sc, n) }
}

/** Встроенные текстуры Avee (internalres:*), нарисованные программно. */
object AveeRes {
    private val m = HashMap<String, Bitmap>()

    private fun radial(size: Int, colors: IntArray, stops: FloatArray): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(size / 2f, size / 2f, size / 2f, colors, stops, Shader.TileMode.CLAMP)
        Canvas(b).drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
        return b
    }

    fun get(n: String): Bitmap? {
        m[n]?.let { return it }
        val b = when {
            n.startsWith("vignette") -> radial(256, intArrayOf(0x00000000, 0x00000000, 0xCC000000.toInt(), 0xFF000000.toInt()), floatArrayOf(0f, 0.5f, 0.85f, 1f))
            n.startsWith("particle_circle_w_a") -> radial(64, intArrayOf(-1, -1, 0), floatArrayOf(0f, 0.7f, 1f))
            n.startsWith("particle_blur01") -> radial(128, intArrayOf(-1, 0x66FFFFFF, 0), floatArrayOf(0f, 0.4f, 1f))
            else -> radial(128, intArrayOf(-1, 0x80FFFFFF.toInt(), 0), floatArrayOf(0f, 0.35f, 1f))
        }
        m[n] = b
        return b
    }
}

// ---------- рендерер ----------

private class Tf(val cx: Float, val cy: Float, val sx: Float, val sy: Float, val rot: Float)

private class PState(cap: Int) {
    val x = FloatArray(cap); val y = FloatArray(cap); val vx = FloatArray(cap); val vy = FloatArray(cap)
    val age = FloatArray(cap); val life = FloatArray(cap)
    var n = 0; var acc = 0f; var last = -1f
}

class AveeRenderer(private val sc: AveeScene) {
    private var W = 1
    private var H = 1
    private var time = 0f
    private var beat = 0f
    private var scaleNow = 1f
    private val pool = ArrayList<Bitmap>()
    private val frameLayers = HashMap<Int, Bitmap>()
    private val parts = IdentityHashMap<JSONObject, PState>()
    private val spec = HashMap<Int, FloatArray>()
    private var coverSrc: Any? = null
    private var coverSoft: Bitmap? = null

    fun frame(dst: Bitmap, t: Float) {
        W = dst.width; H = dst.height; time = t; scaleNow = 1f
        beat = Engine.pulse.coerceIn(0f, 1f)
        spec.clear()
        for (b in frameLayers.values) pool.add(b)
        frameLayers.clear()
        while (pool.size > 40) pool.removeAt(0).recycle()
        dst.eraseColor(0xFF000000.toInt())
        drawComp(Canvas(dst), 0, 0)
    }

    // --- вспомогательное ---

    private fun full() = RectF(0f, 0f, W.toFloat(), H.toFloat())

    private fun obtain(w: Int, h: Int): Bitmap {
        val it = pool.iterator()
        while (it.hasNext()) { val b = it.next(); if (b.width == w && b.height == h) { it.remove(); return b } }
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    }

    private fun tmp(): Bitmap {
        val b = obtain(max(8, (W * scaleNow).toInt()), max(8, (H * scaleNow).toInt()))
        b.eraseColor(0)
        return b
    }

    private fun cv(b: Bitmap): Canvas {
        val c = Canvas(b)
        c.scale(b.width / W.toFloat(), b.height / H.toFloat())
        return c
    }

    private fun release(b: Bitmap) {
        if (frameLayers.containsValue(b)) return
        pool.add(b)
    }

    /** Рисует композицию idx в отдельную текстуру (кэшируется на кадр). */
    private fun layer(idx: Int, depth: Int, scale: Float): Bitmap {
        val key = idx * 1000 + (scaleNow * scale * 100f).toInt()
        frameLayers[key]?.let { return it }
        val prev = scaleNow
        scaleNow = prev * scale
        val b = tmp()
        try { drawComp(cv(b), idx, depth + 1) } finally { scaleNow = prev }
        frameLayers[key] = b
        return b
    }

    private fun coverBmp(): Bitmap? {
        val ib = Look.cover ?: return null
        if (ib === coverSrc) return coverSoft
        val b = ib.asAndroidBitmap()
        coverSoft = if (Build.VERSION.SDK_INT >= 26 && b.config == Bitmap.Config.HARDWARE) b.copy(Bitmap.Config.ARGB_8888, false) else b
        coverSrc = ib
        return coverSoft
    }

    private fun targetOf(e: JSONObject): Int {
        var s = e.st("TargetImage")
        if (s.isEmpty()) s = e.st("targetImage")
        if (s.isEmpty()) s = e.st("sourceCompositionIndex")
        return s.substringAfter(':', s).trim().toFloatOrNull()?.toInt() ?: -1
    }

    // --- измерители (реакция на бит / дрожание / вращение) ---

    private fun measure(e: JSONObject, k: String): Triple<String, Float, Float>? {
        val m = e.optJSONObject(k) ?: return null
        val what = m.st("measureWhat", "Nothing")
        if (what.isEmpty() || what == "Nothing") return null
        return Triple(what, m.nm("A", 0f), m.nm("B", 0f))
    }

    private fun tf(e: JSONObject): Tf {
        val p = e.v2("position", 0.5f, 0.5f)
        val s = e.v2("scale", 1f, 1f)
        var ox = 0f; var oy = 0f
        measure(e, "MeasurePos")?.let { (w, a, b) ->
            val amt = when (w) {
                "BeatCamShakeMore" -> 0.012f * a * beat
                "BeatCamShakeLess" -> 0.006f * a * beat
                "BeatRandomShake" -> 0.010f * a * beat
                "ConstantShakeMore" -> 0.010f * a
                "ConstantShake" -> 0.004f * a
                else -> 0f
            }
            val sp = 3f + b * 4f
            ox = amt * sin(time * sp * 2.1f); oy = amt * cos(time * sp * 1.7f + 1f)
        }
        var rot = e.nm("rotation", 0f)
        measure(e, "measureRot")?.let { (w, a, b) ->
            rot += when (w) {
                "TotalTime", "TotalTimeWhenPlaying", "TotalTimeAndBeat" -> time * a * 60f
                "TotalTimeBackward" -> -time * a * 60f
                "BeatCamShakeRotMore" -> a * 3f * beat * sin(time * 9f)
                "BeatCamShakeRotLess" -> a * 1.5f * beat * sin(time * 9f)
                "ConstantShakeRotMore" -> a * 3f * sin(time * (2f + b * 6f))
                "ConstantShakeRotLess" -> a * 1.5f * sin(time * (2f + b * 6f))
                else -> 0f
            }
        }
        var sx = s[0]; var sy = s[1]
        measure(e, "measureScale")?.let { (w, a, _) ->
            if (w == "Beat" || w == "TotalTimeAndBeat" || w == "BeatTriggerAnim") { val f = 1f + 0.02f * a * beat; sx *= f; sy *= f }
        }
        return Tf((p[0] + ox) * W, (p[1] + oy) * H, sx, sy, rot)
    }

    // --- звук ---

    private fun spectrum(pi: Int, n: Int): FloatArray {
        val key = pi * 1000 + n
        spec[key]?.let { return it }
        val prov = sc.providers.getOrNull((pi - 1).coerceIn(0, max(0, sc.providers.size - 1)))
        val lo = prov?.nm("lowerHz", 40f) ?: 40f
        val hi = max(lo + 10f, prov?.nm("higherHz", 8000f) ?: 8000f)
        val mult = prov?.nm("outputMultiplier", 1f) ?: 1f
        val mirror = prov?.fl("mirrorSamples", false) ?: false
        val rep = (prov?.nm("repeatSamples", 1f) ?: 1f).toInt().coerceIn(1, 6)
        val lin = (prov?.nm("hzLinearFactor", 0f) ?: 0f) > 0.5f
        val sh = Engine.shown
        fun at(f: Float): Float {
            val x = ln(max(f, 40f) / 40f) / ln(200f) * sh.size
            val i = x.toInt().coerceIn(0, sh.size - 2)
            val fr = (x - i).coerceIn(0f, 1f)
            return sh[i] * (1f - fr) + sh[i + 1] * fr
        }
        val m = max(2, if (mirror) n / rep / 2 else n / rep)
        val base = FloatArray(m) { j ->
            val q = j / (m - 1f)
            val f = if (lin) lo + (hi - lo) * q else lo * (hi / lo).pow(q)
            (at(f) * mult).coerceIn(0f, 1.3f)
        }
        val out = FloatArray(n) { i ->
            var u = (i.toFloat() / n * rep) % 1f
            if (mirror) u = if (u < 0.5f) u * 2f else (1f - u) * 2f
            base[(u * (m - 1)).roundToInt().coerceIn(0, m - 1)]
        }
        spec[key] = out
        return out
    }

    // --- композиция ---

    private fun drawComp(c: Canvas, idx: Int, depth: Int) {
        if (depth > 9) return
        val els = sc.comps.getOrNull(idx) ?: return
        for (e in els) {
            val type = e.optString("objType")
            if (type == "AudioProvider" || type == "AppLogo" || type == "DummyElement") continue
            if (!e.fl("visible", true)) continue
            val tag = e.st("tag").lowercase()
            if (tag.contains("intro") || tag.contains("outro")) continue
            try {
                when (type) {
                    "Image" -> image(c, e, depth)
                    "Bars" -> bars(c, e)
                    "Particles" -> particles(c, e, depth)
                    "Text" -> text(c, e)
                    "BlurEffect" -> blur(c, e, depth)
                    "MotionBlurEffect", "FOV", "LiquifyEffect" -> passthrough(c, e, depth)
                    "RgbSplitEffect" -> rgbSplit(c, e, depth)
                    "MirrorEffect" -> mirror(c, e, depth)
                }
            } catch (ex: Exception) { }
        }
    }

    // --- эффекты ---

    private fun passthrough(c: Canvas, e: JSONObject, depth: Int) {
        val tgt = targetOf(e); if (tgt < 0) return
        val b = layer(tgt, depth, 1f)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.xfermode = blendOf(e)
        c.save()
        if (e.optString("objType") == "MotionBlurEffect") {
            val t = tf(e)
            c.translate(t.cx, t.cy); c.rotate(t.rot); c.scale(t.sx, t.sy); c.translate(-W / 2f, -H / 2f)
        }
        c.drawBitmap(b, null, full(), p)
        c.restore()
        release(b)
    }

    private fun blur(c: Canvas, e: JSONObject, depth: Int) {
        val tgt = targetOf(e); if (tgt < 0) return
        val rad = e.nm("blurRadius", 0f)
        val s = (1f / (1f + rad * 3f)).coerceIn(0.18f, 1f)
        val b = layer(tgt, depth, s)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.xfermode = blendOf(e)
        if (rad > 0.01f) p.alpha = (min(1f, 0.55f + 0.2f * e.nm("blurMultiplier", 1f)) * 255f).toInt()
        if (e.fl("showUnblurredContent", false)) {
            val o = layer(tgt, depth, 1f)
            c.drawBitmap(o, null, full(), Paint(Paint.FILTER_BITMAP_FLAG))
            release(o)
        }
        // MaskImage: размытие остаётся только там, где маска непрозрачна
        val maskSrc = e.st("MaskImage")
        var masked: Bitmap? = null
        var maskTemp: Bitmap? = null
        val mb: Bitmap? = when {
            maskSrc.startsWith("composition:") -> layer(maskSrc.substring(12).toIntOrNull() ?: -1, depth, 1f).also { maskTemp = it }
            maskSrc.startsWith("local:") -> AveeAssets.get(sc, maskSrc.substring(6))
            else -> null
        }
        if (mb != null) {
            val lb = tmp()
            val lc = cv(lb)
            lc.drawBitmap(b, null, full(), Paint(Paint.FILTER_BITMAP_FLAG))
            val mp = Paint(Paint.FILTER_BITMAP_FLAG)
            mp.xfermode = DST_IN
            lc.drawBitmap(mb, null, full(), mp)
            masked = lb
        }
        c.drawBitmap(masked ?: b, null, full(), p)
        masked?.let { release(it) }
        maskTemp?.let { release(it) }
        release(b)
    }

    private fun rgbSplit(c: Canvas, e: JSONObject, depth: Int) {
        val tgt = targetOf(e); if (tgt < 0) return
        val b = layer(tgt, depth, 1f)
        val d = W * (0.002f + 0.012f * beat)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.xfermode = blendOf(e)
        c.drawBitmap(b, null, full(), p)
        val pr = Paint(Paint.FILTER_BITMAP_FLAG)
        pr.xfermode = ADD
        pr.colorFilter = ColorMatrixColorFilter(floatArrayOf(1f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0.5f, 0f))
        c.save(); c.translate(-d, 0f); c.drawBitmap(b, null, full(), pr); c.restore()
        val pb = Paint(Paint.FILTER_BITMAP_FLAG)
        pb.xfermode = ADD
        pb.colorFilter = ColorMatrixColorFilter(floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 0.5f, 0f))
        c.save(); c.translate(d, 0f); c.drawBitmap(b, null, full(), pb); c.restore()
        release(b)
    }

    private fun mirror(c: Canvas, e: JSONObject, depth: Int) {
        val tgt = targetOf(e); if (tgt < 0) return
        val b = layer(tgt, depth, 1f)
        val mode = e.st("mirrorMode", "Horizontal")
        val flip = e.fl("flipMirror", false)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.xfermode = blendOf(e)
        c.drawBitmap(b, null, full(), p)
        val w = W.toFloat(); val h = H.toFloat()
        if (mode.contains("Horizontal")) {
            c.save()
            if (!flip) c.clipRect(w / 2f, 0f, w, h) else c.clipRect(0f, 0f, w / 2f, h)
            c.scale(-1f, 1f, w / 2f, 0f)
            c.drawBitmap(b, null, full(), p)
            c.restore()
        }
        if (mode.contains("Vertical")) {
            c.save()
            if (!flip) c.clipRect(0f, h / 2f, w, h) else c.clipRect(0f, 0f, w, h / 2f)
            c.scale(1f, -1f, 0f, h / 2f)
            c.drawBitmap(b, null, full(), p)
            c.restore()
        }
        release(b)
    }

    // --- картинки ---

    private fun image(c: Canvas, e: JSONObject, depth: Int) {
        val src = e.st("customImage")
        val t = tf(e)
        val tintC = e.col("Color", -1)
        var bmp: Bitmap? = null
        var solid = 0   // 1 белый, 2 чёрный, 3 запасной фон, если нет обложки
        var temp = false
        when {
            src.isEmpty() -> { bmp = coverBmp(); if (bmp == null) solid = 3 }
            src.startsWith("composition:") -> { bmp = layer(src.substring(12).toIntOrNull() ?: -1, depth, 1f); temp = true }
            src.startsWith("local:") -> bmp = AveeAssets.get(sc, src.substring(6))
            src.startsWith("internalres:") -> {
                val n = src.substring(12)
                if (n == "transparent") return
                if (n == "white") solid = 1
                else if (n == "black") solid = 2
                else bmp = AveeRes.get(n)
            }
        }
        if (bmp == null && solid == 0) return

        val kar = e.fl("keepAspectRatio", true)
        val crop = e.fl("keepAspectRatioAndCropToFit", false)
        var dw = t.sx * W; var dh = t.sy * H
        var srcRect: Rect? = null
        if (bmp != null && kar && dw > 0f && dh > 0f) {
            val br = bmp.width.toFloat() / bmp.height
            val boxr = dw / dh
            if (crop) {
                srcRect = if (br > boxr) {
                    val nw = (bmp.height * boxr).toInt().coerceAtLeast(1); val x = (bmp.width - nw) / 2
                    Rect(x, 0, x + nw, bmp.height)
                } else {
                    val nh = (bmp.width / boxr).toInt().coerceAtLeast(1); val y = (bmp.height - nh) / 2
                    Rect(0, y, bmp.width, y + nh)
                }
            } else {
                if (br > boxr) dh = dw / br else dw = dh * br
            }
        }
        if (dw <= 0.5f || dh <= 0.5f) { if (temp && bmp != null) release(bmp); return }
        val circle = e.st("Shape") == "Circle"

        val maskSrc = e.st("MaskImage")
        if (maskSrc.isNotEmpty()) {
            val lb = tmp()
            val lc = cv(lb)
            drawImageCore(lc, bmp, srcRect, dw, dh, t, solid, tintC, circle, null)
            var mb: Bitmap? = null
            var mTemp = false
            when {
                maskSrc.startsWith("composition:") -> { mb = layer(maskSrc.substring(12).toIntOrNull() ?: -1, depth, 1f); mTemp = true }
                maskSrc.startsWith("local:") -> mb = AveeAssets.get(sc, maskSrc.substring(6))
                maskSrc.startsWith("internalres:") -> { val n = maskSrc.substring(12); if (n != "white" && n != "black" && n != "transparent") mb = AveeRes.get(n) }
            }
            if (mb != null) {
                val mp = Paint(Paint.FILTER_BITMAP_FLAG)
                mp.xfermode = if (e.st("maskMode") == "InvertedTransparency") DST_OUT else DST_IN
                lc.drawBitmap(mb, null, full(), mp)
                if (mTemp) release(mb)
            }
            val op = Paint(Paint.FILTER_BITMAP_FLAG)
            op.xfermode = blendOf(e)
            c.drawBitmap(lb, null, full(), op)
            release(lb)
        } else {
            drawImageCore(c, bmp, srcRect, dw, dh, t, solid, tintC, circle, blendOf(e))
        }
        if (temp && bmp != null) release(bmp)
    }

    private fun drawImageCore(
        cv: Canvas, bmp: Bitmap?, srcRect: Rect?, dw: Float, dh: Float, t: Tf,
        solid: Int, tintC: Int, circle: Boolean, xf: PorterDuffXfermode?
    ) {
        cv.save()
        cv.translate(t.cx, t.cy)
        if (t.rot != 0f) cv.rotate(t.rot)
        val dst = RectF(-dw / 2f, -dh / 2f, dw / 2f, dh / 2f)
        if (circle) { val path = Path(); path.addOval(dst, Path.Direction.CW); cv.clipPath(path) }
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        p.xfermode = xf
        when {
            solid == 1 -> { p.color = tintC; cv.drawRect(dst, p) }
            solid == 2 -> { p.color = Color.argb(Color.alpha(tintC), 0, 0, 0); cv.drawRect(dst, p) }
            solid == 3 -> { p.color = lerpC(0xFF000000.toInt(), Look.accent.toArgb(), 0.35f); cv.drawRect(dst, p) }
            bmp != null -> { p.colorFilter = tint(tintC); cv.drawBitmap(bmp, srcRect, dst, p) }
        }
        cv.restore()
    }

    // --- спектр-бары ---

    private fun bars(c: Canvas, e: JSONObject) {
        val t = tf(e)
        val shape = e.st("ShapePath", "HorizontalLine")
        val circ = shape == "Circle" || shape.startsWith("Sided")
        val pi = e.nm("audioProviderIndex", 1f).toInt()
        val hs = e.nm("heightScale", 1f)
        val minH = e.nm("minHeightScale", 0.01f)
        val maxH = e.nm("maxHeightScale", 1f)
        val flipIn = e.fl("flipInput", false)
        val rad = e.optJSONObject("ShapePath")?.nm("radius", 1f) ?: 1f
        val n = if (circ) 120 else 96
        val data = spectrum(pi, if (circ) n / 2 else n)
        val xf = blendOf(e)
        for (segName in arrayOf("Segment1", "Segment2")) {
            val kind = e.st(segName, "None")
            if (kind == "None" || kind.isEmpty()) continue
            val seg = e.optJSONObject(segName) ?: continue
            val cf = seg.col("colorFrom", -1); val ct = seg.col("colorTo", -1)
            val mir = seg.fl("mirror", false); val alt = seg.fl("flipEveryOther", false)
            val mulH = seg.nm("barHeightMultiplier", 1f); val fixed = seg.nm("fixedHeight", 0f)
            val bwf = seg.nm("barWidth", 0.7f).coerceIn(0.05f, 1.5f)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.xfermode = xf
            p.strokeCap = if (kind.contains("Round")) Paint.Cap.ROUND else Paint.Cap.BUTT
            c.save()
            c.translate(t.cx, t.cy)
            if (t.rot != 0f) c.rotate(t.rot)
            if (!circ) {
                val span = W * t.sx; val unit = H * t.sy; val step = span / n
                p.strokeWidth = if (kind == "Line") max(2f, step * 0.18f) else max(2f, step * bwf)
                for (i in 0 until n) {
                    val v = data[(if (flipIn) n - 1 - i else i).coerceIn(0, data.size - 1)].coerceIn(0f, 1.2f)
                    val len = (minH + v * (maxH - minH)) * hs * mulH * unit * 0.5f + fixed
                    val dir = if (alt && i % 2 == 1) 1f else -1f
                    val x = -span / 2f + step * (i + 0.5f)
                    p.color = lerpC(cf, ct, i / (n - 1f))
                    c.drawLine(x, 0f, x, dir * len, p)
                    if (mir) c.drawLine(x, 0f, x, -dir * len, p)
                }
            } else {
                val unit = min(W, H) * t.sx * 0.5f
                val r0 = unit * rad
                val step = (2.0 * PI).toFloat() / n
                p.strokeWidth = max(2f, r0 * step * (if (kind == "Line") 0.25f else bwf))
                for (i in 0 until n) {
                    val k = if (i < n / 2) i else n - 1 - i
                    val v = data[(if (flipIn) data.size - 1 - k else k).coerceIn(0, data.size - 1)].coerceIn(0f, 1.2f)
                    val len = (minH + v * (maxH - minH)) * hs * mulH * unit + fixed
                    val ang = i * step - (PI / 2.0).toFloat()
                    val ca = cos(ang); val sa = sin(ang)
                    val dir = if (alt && i % 2 == 1) -1f else 1f
                    p.color = lerpC(cf, ct, k / (n / 2f))
                    c.drawLine(r0 * ca, r0 * sa, (r0 + dir * len) * ca, (r0 + dir * len) * sa, p)
                    if (mir) c.drawLine(r0 * ca, r0 * sa, (r0 - dir * len) * ca, (r0 - dir * len) * sa, p)
                }
            }
            c.restore()
        }
    }

    // --- частицы ---

    private fun particles(c: Canvas, e: JSONObject, depth: Int) {
        val cap = e.nm("CountLimit", 300f).toInt().coerceIn(20, 260)
        val st = parts.getOrPut(e) { PState(cap) }
        val dt = if (st.last < 0f) 0f else (time - st.last).coerceIn(0f, 0.05f)
        st.last = time
        val t = tf(e)
        val life = e.nm("lifetime", 3f).coerceAtLeast(0.2f)
        val spawn = e.nm("spawnTime", 0.02f).coerceAtLeast(0.004f)
        val speed = e.nm("Speed", 100f)
        val sr = e.nm("speedRandom", 0f)
        val grav = e.v2("gravity", 0f, 0f)
        val unit = H * 0.0014f

        var i = 0
        while (i < st.n) {
            st.age[i] += dt
            if (st.age[i] >= st.life[i]) {
                val l = st.n - 1
                st.x[i] = st.x[l]; st.y[i] = st.y[l]; st.vx[i] = st.vx[l]; st.vy[i] = st.vy[l]
                st.age[i] = st.age[l]; st.life[i] = st.life[l]
                st.n--
                continue
            }
            st.x[i] += st.vx[i] * dt; st.y[i] += st.vy[i] * dt
            st.vx[i] += grav[0] * unit * dt; st.vy[i] += grav[1] * unit * dt
            i++
        }
        st.acc += dt * (1f + beat * 0.6f)
        while (st.acc >= spawn && st.n < cap) {
            st.acc -= spawn
            val k = st.n++
            st.x[k] = t.cx + (Random.nextFloat() - 0.5f) * W * t.sx
            st.y[k] = t.cy + (Random.nextFloat() - 0.5f) * H * t.sy
            val a = Random.nextFloat() * (2.0 * PI).toFloat()
            val sp = (speed + sr * (Random.nextFloat() - 0.5f) * 2f) * unit * (1f + beat * 0.8f)
            st.vx[k] = cos(a) * sp; st.vy[k] = sin(a) * sp
            st.age[k] = 0f; st.life[k] = life * (0.7f + 0.3f * Random.nextFloat())
        }
        if (st.acc > 1f) st.acc = 0f

        val ps = e.nm("particleScale", 4f)
        val s0 = e.nm("startSize", 1f); val s1 = e.nm("endSize", 2f)
        val cA = e.col("ColorFrom", -1); val cB = e.col("ColorTo", -1)
        val fade = e.nm("fadeInAndOutTime", 0.2f).coerceIn(0.02f, 0.5f)
        val srcName = e.st("customImage")
        var tempSprite = false
        val sprite: Bitmap = when {
            srcName.startsWith("internalres:") -> AveeRes.get(srcName.substring(12))
            srcName.startsWith("local:") -> AveeAssets.get(sc, srcName.substring(6)) ?: AveeRes.get("particle_circle_blur4")
            srcName.startsWith("composition:") -> {
                val ci = srcName.substring(12).toIntOrNull() ?: -1
                if (ci < 0 || ci >= sc.comps.size) AveeRes.get("particle_circle_blur4")
                else { tempSprite = true; layer(ci, depth, 0.25f) }
            }
            else -> AveeRes.get("particle_circle_blur4")
        } ?: return
        val unitSize = ps * 0.25f * (H / 1080f)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.xfermode = blendOf(e)
        val sr2 = RectF()
        for (j in 0 until st.n) {
            val f = (st.age[j] / st.life[j]).coerceIn(0f, 1f)
            val size = max(2f, (s0 + (s1 - s0) * f) * unitSize)
            val a = min(1f, min(f / fade, (1f - f) / fade))
            val col = lerpC(cA, cB, f)
            p.alpha = (a * Color.alpha(col)).toInt().coerceIn(0, 255)
            p.colorFilter = LightingColorFilter(col or 0xFF000000.toInt(), 0)
            sr2.set(st.x[j] - size / 2f, st.y[j] - size / 2f, st.x[j] + size / 2f, st.y[j] + size / 2f)
            c.drawBitmap(sprite, null, sr2, p)
        }
        if (tempSprite) release(sprite)
    }

    // --- текст ---

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return String.format(java.util.Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    private fun text(c: Canvas, e: JSONObject) {
        val t = tf(e)
        val pl = Audio.player
        val pos = pl.currentPosition
        val dur = if (pl.duration > 0) pl.duration else (App.current?.durMs ?: 0L)
        val s = e.st("text")
            .replace("{TimeCurrent}", fmt(pos))
            .replace("{TimeRemaining}", "-" + fmt(dur - pos))
            .replace("{Title}", App.current?.title ?: "")
            .replace("{Artist}", App.current?.artist ?: "")
            .replace("{Album}", App.current?.album ?: "")
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = e.col("color", -1)
        p.textSize = e.nm("fontSize", 20f) * H / 1000f
        p.textAlign = Paint.Align.CENTER
        p.xfermode = blendOf(e)
        c.save()
        c.translate(t.cx, t.cy)
        if (t.rot != 0f) c.rotate(t.rot)
        c.drawText(s, 0f, p.textSize * 0.35f, p)
        c.restore()
    }
}

// ---------- вывод в Compose ----------

private var vRend: AveeRenderer? = null
private var vBmp: Bitmap? = null
private var vKey = ""

fun DrawScope.drawAvee(sc: AveeScene, t: Float) {
    val w = size.width; val h = size.height
    if (w < 8f || h < 8f) return
    val s = min(1f, 1280f * Cfg.vizQuality.coerceIn(0.3f, 1f) / max(w, h))
    val bw = max(32, (w * s).toInt()); val bh = max(32, (h * s).toInt())
    val old = vBmp
    val b: Bitmap = if (old != null && old.width == bw && old.height == bh) old else {
        old?.recycle()
        vRend = null
        Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888).also { vBmp = it }
    }
    val cur = vRend
    val r: AveeRenderer = if (cur != null && vKey == sc.id) cur else AveeRenderer(sc).also { vRend = it; vKey = sc.id }
    r.frame(b, t)
    drawIntoCanvas { c -> c.nativeCanvas.drawBitmap(b, null, RectF(0f, 0f, w, h), Paint(Paint.FILTER_BITMAP_FLAG)) }
}
