package com.dizz.player

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

class VizInfo(val id: String, val sizeKb: Long)

/** Папка с подключёнными шаблонами .viz: импорт, список, выбор, удаление. */
object VizStore {
    var list by mutableStateOf<List<VizInfo>>(emptyList())
    var active by mutableStateOf<AveeScene?>(null)
    var loading by mutableStateOf(false)
    var message by mutableStateOf("")

    private val main = Handler(Looper.getMainLooper())
    private fun dir(c: Context) = File(c.filesDir, "viz")

    fun init(c: Context) {
        refresh(c)
        if (Cfg.vizPack.isNotEmpty()) activate(c, Cfg.vizPack)
    }

    fun refresh(c: Context) {
        list = dir(c).listFiles()
            ?.filter { it.isFile && it.name.endsWith(".viz", true) }
            ?.sortedBy { it.name.lowercase() }
            ?.map { VizInfo(it.nameWithoutExtension, it.length() / 1024) }
            ?: emptyList()
    }

    /** id == "" — вернуться к встроенным визуализациям. */
    fun activate(c: Context, id: String) {
        if (id.isNotEmpty() && id == Cfg.vizPack && (active?.id == id || loading)) return
        Cfg.vizPack = id
        if (id.isEmpty()) { active = null; loading = false; return }
        val f = File(dir(c), "$id.viz")
        loading = true
        Thread {
            try {
                val sc = Avee.parse(f, id)
                AveeAssets.preload(sc)
                active = sc
                message = ""
            } catch (e: Throwable) {
                active = null
                Cfg.vizPack = ""
                message = "Не удалось загрузить «$id»: ${e.message}"
            }
            loading = false
        }.start()
    }

    fun delete(c: Context, id: String) {
        File(dir(c), "$id.viz").delete()
        if (Cfg.vizPack == id) { Cfg.vizPack = ""; active = null }
        refresh(c)
    }

    private fun displayName(c: Context, uri: Uri): String {
        var name = ""
        try {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) name = it.getString(0) ?: ""
            }
        } catch (e: Exception) { }
        if (name.isBlank()) name = uri.lastPathSegment?.substringAfterLast('/') ?: "preset.viz"
        return name
    }

    /** Копирует файл в приложение, проверяет, что это шаблон, возвращает id. Вызывать не из главного потока. */
    fun import(c: Context, uri: Uri): String {
        val d = dir(c); d.mkdirs()
        val raw = displayName(c, uri).removeSuffix(".viz").removeSuffix(".VIZ")
        val base = raw.replace(Regex("[^\\p{L}\\p{N}_\\- .]"), "_").trim().ifEmpty { "viz" }.take(60)
        val tmp = File(d, "$base.tmp")
        try {
            (c.contentResolver.openInputStream(uri) ?: throw Exception("не удалось открыть файл")).use { i ->
                tmp.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024); var total = 0L
                    while (true) {
                        val n = i.read(buf); if (n < 0) break
                        total += n
                        if (total > 120L * 1024 * 1024) throw Exception("файл больше 120 МБ")
                        o.write(buf, 0, n)
                    }
                }
            }
            if (!Avee.looksValid(tmp)) throw Exception("это не шаблон визуализации (нет scene.json внутри архива)")
            Avee.parse(tmp, base)   // проверка, что сцена читается
            val dst = File(d, "$base.viz")
            if (dst.exists()) dst.delete()
            if (!tmp.renameTo(dst)) throw Exception("не удалось сохранить файл")
        } finally {
            tmp.delete()
        }
        refresh(c)
        return base
    }

    /** Импорт в фоне + выбор + уведомление. Безопасно звать из любого потока. */
    fun importAsync(c: Context, uri: Uri) {
        val app = c.applicationContext
        Thread {
            val r = runCatching { import(app, uri) }
            main.post {
                r.onSuccess {
                    message = "Подключено: $it"
                    Toast.makeText(app, "Визуализация «$it» подключена", Toast.LENGTH_SHORT).show()
                    activate(app, it)
                }.onFailure {
                    message = "Не удалось добавить .viz: ${it.message}"
                    Toast.makeText(app, message, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
